const request = require('supertest');
const express = require('express');
const parkingRouter = require('../mvc/routes/parkingRoutes');
const parkingController = require('../mvc/controllers/parkingController');

// Simula o módulo do controller. Todas as suas funções se tornam "espiãs".
jest.mock('../mvc/controllers/parkingController');

// Cria um servidor Express de teste
const app = express();
app.use(express.json()); // Adiciona middleware para o Express entender corpos de requisição JSON
app.use('/', parkingRouter); // Diz ao servidor para usar as rotas que queremos testar

describe('Testes das Rotas de Estacionamento', () => {

    // Limpa o histórico dos mocks após cada teste
    afterEach(() => {
        jest.clearAllMocks();
    });

    test('GET / deve chamar a função exibirDashboard do controller', async () => {
        // Configura a função simulada para enviar uma resposta e evitar que o teste trave
        parkingController.exibirDashboard.mockImplementation((req, res) => res.sendStatus(200));

        // Simula uma requisição GET para a rota raiz
        await request(app).get('/');

        // Verifica se a função correta foi chamada
        expect(parkingController.exibirDashboard).toHaveBeenCalledTimes(1);
    });

    test('POST /registrar-entrada deve chamar a função registrarEntradaVeiculo', async () => {
        parkingController.registrarEntradaVeiculo.mockImplementation((req, res) => res.sendStatus(200));

        // Simula uma requisição POST com dados no corpo
        await request(app).post('/registrar-entrada').send({ placa: 'TEST-001', modelo: 'Carro Teste', cor: 'Preto' });

        expect(parkingController.registrarEntradaVeiculo).toHaveBeenCalledTimes(1);
    });

    test('POST /registrar-saida/:placa deve chamar a função registrarSaidaVeiculo', async () => {
        parkingController.registrarSaidaVeiculo.mockImplementation((req, res) => res.sendStatus(200));

        const placaTeste = 'ABC-1234';
        // Simula uma requisição POST para uma rota com parâmetro
        await request(app).post(`/registrar-saida/${placaTeste}`);

        expect(parkingController.registrarSaidaVeiculo).toHaveBeenCalledTimes(1);
    });

    test('POST /registrar-retorno/:placa deve chamar a função registrarRetornoVeiculo', async () => {
        parkingController.registrarRetornoVeiculo.mockImplementation((req, res) => res.sendStatus(200));

        const placaTeste = 'DEF-5678';
        await request(app).post(`/registrar-retorno/${placaTeste}`);

        expect(parkingController.registrarRetornoVeiculo).toHaveBeenCalledTimes(1);
    });

    test('POST /toggle-block/:placa deve chamar a função alternarBloqueioVeiculo', async () => {
        parkingController.alternarBloqueioVeiculo.mockImplementation((req, res) => res.sendStatus(200));
        
        const placaTeste = 'GHI-9012';
        await request(app).post(`/toggle-block/${placaTeste}`);

        expect(parkingController.alternarBloqueioVeiculo).toHaveBeenCalledTimes(1);
    });
});