const request = require('supertest');
const express = require('express');
const authRouter = require('../mvc/routes/authRoutes');

// Importamos o controller apenas para que o Jest possa "escutar" suas funções
const authController = require('../mvc/controllers/authController');

// A linha mais importante: diz ao Jest para substituir o controller real por um simulado.
// Todas as funções (exibirPaginaLogin, etc.) se tornarão "espiãs" do Jest.
jest.mock('../mvc/controllers/authController');

// 1. Criamos um servidor Express de teste
const app = express();
// Garantimos que o app consiga ler o corpo de requisições POST
app.use(express.json());
// 2. Dizemos ao servidor para usar nosso arquivo de rotas
app.use('/', authRouter);

describe('Testes das Rotas de Autenticação', () => {

    // Limpamos os mocks após cada teste para garantir que um teste não interfira no outro
    afterEach(() => {
        jest.clearAllMocks();
    });

    test('Deve chamar o controller correto para GET /login', async () => {
        // Para a requisição não ficar "pendurada", configuramos a função simulada para responder
        authController.exibirPaginaLogin.mockImplementation((req, res) => res.sendStatus(200));

        // 3. Usamos o Supertest para fazer uma requisição GET para a rota /login
        await request(app).get('/login');

        // 4. Verificamos se a função correta do controller simulado foi chamada
        expect(authController.exibirPaginaLogin).toHaveBeenCalledTimes(1);
    });

    test('Deve chamar o controller correto para POST /login', async () => {
        authController.efetuarLogin.mockImplementation((req, res) => res.sendStatus(200));

        // Usamos .send() para enviar dados no corpo da requisição POST
        await request(app).post('/login').send({ username: 'teste', password: '123' });

        expect(authController.efetuarLogin).toHaveBeenCalledTimes(1);
    });

    test('Deve chamar o controller correto para GET /logout', async () => {
        authController.efetuarLogout.mockImplementation((req, res) => res.sendStatus(200));

        await request(app).get('/logout');

        expect(authController.efetuarLogout).toHaveBeenCalledTimes(1);
    });
});