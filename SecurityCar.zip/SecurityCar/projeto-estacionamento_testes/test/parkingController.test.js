// Importa o controller que vamos testar
const {
    exibirDashboard,
    registrarEntradaVeiculo,
    registrarSaidaVeiculo,
    registrarRetornoVeiculo,
    alternarBloqueioVeiculo
} = require('../mvc/controllers/parkingController');

// Importa o model para que possamos "mocká-lo" (simulá-lo)
const Veiculo = require('../mvc/models/veiculo');

// A linha mais importante: diz ao Jest para substituir o model real por uma simulação
jest.mock('../mvc/models/veiculo');

// Dados de exemplo que usaremos nos testes
const mockVeiculosNoPatio = [{ placa: 'ABC-1234', modelo: 'Carro A', cor: 'Azul', horario_saida: null }];
const mockHistorico = [{ placa: 'XYZ-5678', modelo: 'Carro B', cor: 'Preto', horario_saida: new Date() }];

describe('Parking Controller', () => {

    let req, res;

    // Antes de cada teste, resetamos os objetos req e res e limpamos os mocks
    beforeEach(() => {
        jest.clearAllMocks();
        req = {
            query: {},
            body: {},
            params: {},
            session: { user: 'testuser' }
        };
        res = {
            render: jest.fn(),
            redirect: jest.fn(),
            status: jest.fn().mockReturnThis(), // Permite encadear chamadas como res.status().send()
            send: jest.fn()
        };
    });

    describe('exibirDashboard', () => {
        it('deve buscar e exibir todos os veículos quando não há pesquisa', async () => {
            // Configura o retorno simulado das funções do model
            Veiculo.obterEstacionados.mockResolvedValue(mockVeiculosNoPatio);
            Veiculo.obterHistoricoSaidas.mockResolvedValue(mockHistorico);

            // Executa a função do controller
            await exibirDashboard(req, res);

            // Verifica se a página foi renderizada com os dados corretos
            expect(res.render).toHaveBeenCalledWith('dashboard', {
                veiculosNoPatio: mockVeiculosNoPatio,
                historicoSaidas: mockHistorico,
                totalCars: mockVeiculosNoPatio.length,
                user: 'testuser'
            });
        });

        it('deve buscar e exibir veículos filtrados quando há pesquisa', async () => {
            req.query.placa_pesquisa = 'ABC';
            const mockResultadoBusca = [{ placa: 'ABC-1234', modelo: 'Carro A', cor: 'Azul', horario_saida: null }];
            Veiculo.buscarRegistrosPorPlaca.mockResolvedValue(mockResultadoBusca);
            Veiculo.obterEstacionados.mockResolvedValue(mockVeiculosNoPatio); // Para o totalCars

            await exibirDashboard(req, res);

            expect(Veiculo.buscarRegistrosPorPlaca).toHaveBeenCalledWith('ABC');
            expect(res.render).toHaveBeenCalledWith('dashboard', expect.objectContaining({
                veiculosNoPatio: mockResultadoBusca,
                historicoSaidas: []
            }));
        });
    });

    describe('registrarEntradaVeiculo', () => {
        it('deve registrar um veículo e redirecionar', async () => {
            req.body = { placa: 'NEW-0001', modelo: 'Carro Novo', cor: 'Verde' };
            // Simula que o veículo não existe ou não está bloqueado
            Veiculo.buscarPorPlaca.mockResolvedValue(null); 

            await registrarEntradaVeiculo(req, res);

            // Verifica se o model foi chamado com os dados corretos
            expect(Veiculo.registrarEntrada).toHaveBeenCalledWith({
                placa: 'NEW-0001',
                modelo: 'Carro Novo',
                cor: 'Verde'
            });
            // Verifica se houve o redirecionamento
            expect(res.redirect).toHaveBeenCalledWith('/dashboard');
        });

        it('não deve registrar um veículo bloqueado e retornar erro 403', async () => {
            req.body = { placa: 'BLK-0002', modelo: 'Carro Bloqueado', cor: 'Preto' };
            // Simula que o veículo existe e está bloqueado
            Veiculo.buscarPorPlaca.mockResolvedValue({ bloqueado: true });

            await registrarEntradaVeiculo(req, res);

            // Verifica se o registro NÃO foi chamado
            expect(Veiculo.registrarEntrada).not.toHaveBeenCalled();
            // Verifica se o status de erro foi enviado
            expect(res.status).toHaveBeenCalledWith(403);
            expect(res.send).toHaveBeenCalledWith('Este veículo está bloqueado e não pode entrar.');
        });
    });

    describe('registrarSaidaVeiculo', () => {
        it('deve registrar a saída de um veículo e redirecionar', async () => {
            req.params.placa = 'ABC-1234';
            
            await registrarSaidaVeiculo(req, res);

            expect(Veiculo.registrarSaida).toHaveBeenCalledWith('ABC-1234');
            expect(res.redirect).toHaveBeenCalledWith('/dashboard');
        });
    });

    describe('registrarRetornoVeiculo', () => {
        it('deve registrar o retorno de um veículo e redirecionar', async () => {
            req.params.placa = 'XYZ-5678';
            const veiculoDoHistorico = { placa: 'XYZ-5678', modelo: 'Carro B', cor: 'Preto' };
            Veiculo.buscarPorPlaca.mockResolvedValue(veiculoDoHistorico);

            await registrarRetornoVeiculo(req, res);

            expect(Veiculo.buscarPorPlaca).toHaveBeenCalledWith('XYZ-5678');
            expect(Veiculo.registrarEntrada).toHaveBeenCalledWith(veiculoDoHistorico);
            expect(res.redirect).toHaveBeenCalledWith('/dashboard');
        });
    });
    
    describe('alternarBloqueioVeiculo', () => {
        it('deve alternar o status de bloqueio e redirecionar', async () => {
            req.params.placa = 'ABC-1234';
            
            await alternarBloqueioVeiculo(req, res);

            expect(Veiculo.alternarBloqueio).toHaveBeenCalledWith('ABC-1234');
            expect(res.redirect).toHaveBeenCalledWith('/dashboard');
        });
    });
});