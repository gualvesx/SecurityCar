
const { exibirPaginaLogin, efetuarLogin, efetuarLogout } = require('../mvc/controllers/authController');

describe('Auth Controller', () => {

    describe('exibirPaginaLogin', () => {
        it('deve renderizar a página de login sem erros', () => {
            
            const req = {}; // A requisição não é usada nesta função
            const res = {
                render: jest.fn() // jest.fn() cria uma função "espiã" para monitorar chamadas
            };

            // 2. Executa a função
            exibirPaginaLogin(req, res);

            // 3. Verifica o resultado (Assertions)
            // Esperamos que res.render tenha sido chamado com 'login' e { error: null }
            expect(res.render).toHaveBeenCalledWith('login', { error: null });
            // Verificamos também se foi chamado apenas uma vez
            expect(res.render).toHaveBeenCalledTimes(1);
        });
    });

    // Testes para a função de efetuar login
    describe('efetuarLogin', () => {
        it('deve redirecionar para /dashboard com credenciais corretas', () => {
            // 1. Simula uma requisição com dados corretos no body e um objeto de sessão
            const req = {
                body: { username: 'seguranca', password: 'senha123' },
                session: {} // A sessão começa vazia
            };
            const res = {
                redirect: jest.fn() // Cria uma função espiã para o redirect
            };

            // 2. Executa a função
            efetuarLogin(req, res);

            // 3. Verifica os resultados
            // Esperamos que a sessão agora tenha os dados do usuário
            expect(req.session.user).toEqual({ username: 'seguranca' });
            // Esperamos que o redirecionamento para o dashboard tenha sido chamado
            expect(res.redirect).toHaveBeenCalledWith('/dashboard');
        });

        it('deve renderizar a página de login com erro com credenciais incorretas', () => {
            // 1. Simula uma requisição com dados incorretos
            const req = {
                body: { username: 'errado', password: '123' }
            };
            const res = {
                render: jest.fn()
            };

            // 2. Executa a função
            efetuarLogin(req, res);

            // 3. Verifica o resultado
            // Esperamos que a página de login seja renderizada com uma mensagem de erro
            expect(res.render).toHaveBeenCalledWith('login', { error: 'Credenciais inválidas.' });
        });
    });

    // Testes para a função de efetuar logout
    describe('efetuarLogout', () => {
        it('deve destruir a sessão e redirecionar para /login', () => {
            // 1. Simula a função destroy da sessão, fazendo com que ela execute o callback imediatamente
            const mockDestroy = jest.fn((callback) => {
                callback();
            });
            const req = {
                session: {
                    destroy: mockDestroy
                }
            };
            const res = {
                redirect: jest.fn()
            };

            // 2. Executa a função
            efetuarLogout(req, res);

            // 3. Verifica os resultados
            // Esperamos que a função para destruir a sessão tenha sido chamada
            expect(mockDestroy).toHaveBeenCalledTimes(1);
            // Esperamos que o redirecionamento para a página de login tenha sido chamado
            expect(res.redirect).toHaveBeenCalledWith('/login');
        });
    });

});