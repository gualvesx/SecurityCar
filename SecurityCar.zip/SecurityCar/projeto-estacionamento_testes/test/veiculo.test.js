// Importamos o model que queremos testar
const Veiculo = require('../mvc/models/veiculo');
// Importamos o pool apenas para que o Jest possa "vigiá-lo"
const pool = require('../config/db');

// A MÁGICA ACONTECE AQUI:
// Dizemos ao Jest: "Quando alguém pedir o arquivo '../config/db', não entregue o real.
// Em vez disso, entregue este objeto falso que criamos."
jest.mock('../config/db', () => ({
    // A função query é a mais importante. Ela deve ser uma função de mock do Jest.
    query: jest.fn(),
    // Também simulamos getConnection para a função de transação (registrarEntrada)
    getConnection: jest.fn(),
}));

// Dados de exemplo para usar nos testes
const mockVeiculo = { placa: 'ABC-1234', modelo: 'Teste', cor: 'Preto', bloqueado: false };

describe('Veiculo Model', () => {

    // Antes de cada teste, limpamos o histórico de todas as funções simuladas
    beforeEach(() => {
        jest.clearAllMocks();
    });
// Adicione este código dentro do describe('Veiculo Model', ...) em test/veiculo.test.js

    describe('obterHistoricoSaidas', () => {
        it('deve retornar uma lista de veículos do histórico', async () => {
            // 1. Configuração
            const mockListaHistorico = [{ placa: 'XYZ-5678', modelo: 'Histórico', cor: 'Preto', horario_saida: new Date() }];
            pool.query.mockResolvedValue([ mockListaHistorico ]);

            // 2. Ação
            const result = await Veiculo.obterHistoricoSaidas();

            // 3. Verificação
            expect(pool.query).toHaveBeenCalledWith(expect.stringContaining('WHERE r.horario_saida IS NOT NULL'));
            expect(result).toEqual(mockListaHistorico);
        });
    });
    describe('buscarPorPlaca', () => {
        it('deve retornar um veículo quando encontrado', async () => {
            // 1. Configuração: Dizemos ao mock para retornar nosso veículo de exemplo
            pool.query.mockResolvedValue([ [mockVeiculo] ]); // mysql2/promise retorna [[rows], [fields]]

            // 2. Ação: Executamos a função do model
            const result = await Veiculo.buscarPorPlaca('ABC-1234');

            // 3. Verificação: Conferimos se a query foi chamada corretamente e se o resultado é o esperado
            expect(pool.query).toHaveBeenCalledWith('SELECT * FROM veiculos WHERE placa = ?', ['ABC-1234']);
            expect(result).toEqual(mockVeiculo);
        });

        it('deve retornar undefined quando o veículo não é encontrado', async () => {
            // Configuração: Dizemos ao mock para retornar um array vazio
            pool.query.mockResolvedValue([ [] ]);

            const result = await Veiculo.buscarPorPlaca('XYZ-9999');

            expect(result).toBeUndefined();
        });
    });

    // Adicione este código em test/veiculo.test.js

    describe('alternarBloqueio', () => {
        it('deve retornar true se o status de bloqueio for alterado', async () => {
            // 1. Configuração: Simula um resultado de UPDATE bem-sucedido
            pool.query.mockResolvedValue([ { affectedRows: 1 } ]);

            // 2. Ação
            const result = await Veiculo.alternarBloqueio('ABC-1234');

            // 3. Verificação
            expect(pool.query).toHaveBeenCalledWith('UPDATE veiculos SET bloqueado = NOT bloqueado WHERE placa = ?', ['ABC-1234']);
            expect(result).toBe(true);
        });

        it('deve retornar false se nenhum veículo for encontrado para bloquear', async () => {
            // 1. Configuração: Simula um resultado de UPDATE que não afetou nenhuma linha
            pool.query.mockResolvedValue([ { affectedRows: 0 } ]);
            
            // 2. Ação
            const result = await Veiculo.alternarBloqueio('XYZ-9999');

            // 3. Verificação
            expect(result).toBe(false);
        });
    });
    
    describe('obterEstacionados', () => {
        it('deve retornar uma lista de veículos estacionados', async () => {
            const mockLista = [mockVeiculo];
            pool.query.mockResolvedValue([ mockLista ]);

            const result = await Veiculo.obterEstacionados();

            expect(pool.query).toHaveBeenCalledWith(expect.stringContaining('WHERE r.horario_saida IS NULL'));
            expect(result).toEqual(mockLista);
        });
    });

    // Adicione este código ao final de `test/veiculo.test.js`

    describe('buscarRegistrosPorPlaca', () => {
        it('deve retornar uma lista de registros correspondentes à placa', async () => {
            const mockResultadoBusca = [
                { placa: 'ABC-1234', modelo: 'Teste', cor: 'Preto' }
            ];
            pool.query.mockResolvedValue([mockResultadoBusca]);

            const result = await Veiculo.buscarRegistrosPorPlaca('ABC');

            // Verifica se a query usou LIKE e o operador '%'
            expect(pool.query).toHaveBeenCalledWith(expect.any(String), ['%ABC%']);
            expect(result).toEqual(mockResultadoBusato);
        });
    });

    describe('registrarEntrada', () => {
        // Simulação mais complexa para a transação
        const mockConnection = {
            beginTransaction: jest.fn().mockResolvedValue(),
            query: jest.fn().mockResolvedValue(),
            commit: jest.fn().mockResolvedValue(),
            rollback: jest.fn().mockResolvedValue(),
            release: jest.fn().mockResolvedValue(),
        };
        
        it('deve executar uma transação e registrar a entrada', async () => {
            // Dizemos ao mock de getConnection para retornar nossa conexão simulada
            pool.getConnection.mockResolvedValue(mockConnection);
            
            const dados = { placa: 'NEW-0001', modelo: 'Novo', cor: 'Branco' };
            const result = await Veiculo.registrarEntrada(dados);

            expect(pool.getConnection).toHaveBeenCalledTimes(1);
            expect(mockConnection.beginTransaction).toHaveBeenCalledTimes(1);
            expect(mockConnection.query).toHaveBeenCalledTimes(2); // Uma para INSERT/UPDATE, outra para INSERT
            expect(mockConnection.commit).toHaveBeenCalledTimes(1);
            expect(mockConnection.rollback).not.toHaveBeenCalled();
            expect(mockConnection.release).toHaveBeenCalledTimes(1);
            expect(result).toBe(true);
        });
        
        it('deve dar rollback em caso de erro na query', async () => {
            pool.getConnection.mockResolvedValue(mockConnection);
            // Simulamos um erro na query
            mockConnection.query.mockRejectedValue(new Error('Falha na query'));
            
            const dados = { placa: 'ERR-0001', modelo: 'Erro', cor: 'Erro' };
            const result = await Veiculo.registrarEntrada(dados);

            expect(mockConnection.commit).not.toHaveBeenCalled();
            expect(mockConnection.rollback).toHaveBeenCalledTimes(1);
            expect(result).toBe(false);
        });
    });

    describe('registrarSaida', () => {
        it('deve retornar true se uma linha for afetada', async () => {
            // Simulamos o objeto de resultado de um UPDATE
            pool.query.mockResolvedValue([ { affectedRows: 1 } ]);
            
            const result = await Veiculo.registrarSaida('ABC-1234');

            expect(pool.query).toHaveBeenCalledWith(expect.stringContaining('UPDATE registros SET horario_saida'), expect.any(Array));
            expect(result).toBe(true);
        });

        it('deve retornar false se nenhuma linha for afetada', async () => {
            pool.query.mockResolvedValue([ { affectedRows: 0 } ]);
            
            const result = await Veiculo.registrarSaida('XYZ-9999');

            expect(result).toBe(false);
        });
    });

});