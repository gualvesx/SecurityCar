const Veiculo = require('../models/veiculo');

// A função principal agora é async e com a lógica de busca
const exibirDashboard = async (req, res) => {
  try {
    // Pega o parâmetro de busca da URL (ex: /dashboard?placa_pesquisa=ABC)
    const { placa_pesquisa } = req.query;
    let veiculosNoPatio = [];
    let historicoSaidas = [];

    if (placa_pesquisa) {
      // Se o usuário pesquisou por uma placa...
      const todosOsRegistros = await Veiculo.buscarRegistrosPorPlaca(placa_pesquisa);
      // Filtra os resultados da busca entre os que estão no pátio e os que já saíram
      veiculosNoPatio = todosOsRegistros.filter(v => v.horario_saida === null);
      historicoSaidas = todosOsRegistros.filter(v => v.horario_saida !== null);
    } else {
      // Se não houve pesquisa, carrega a lista completa normalmente
      veiculosNoPatio = await Veiculo.obterEstacionados();
      historicoSaidas = await Veiculo.obterHistoricoSaidas();
    }
    
    // O total de carros para o card de resumo deve ser sempre o total real no pátio
    const totalDeCarrosNoPatio = await Veiculo.obterEstacionados();

    res.render('dashboard', {
      veiculosNoPatio,
      historicoSaidas,
      totalCars: totalDeCarrosNoPatio.length,
      user: req.session.user
    });
  } catch (error) {
    console.error(error);
    res.status(500).send("Erro ao buscar dados do estacionamento.");
  }
};

const registrarEntradaVeiculo = async (req, res) => {
  const { placa, modelo, cor } = req.body;
  
  const veiculoExistente = await Veiculo.buscarPorPlaca(placa.toUpperCase());
  if (veiculoExistente && veiculoExistente.bloqueado) {
      return res.status(403).send("Este veículo está bloqueado e não pode entrar.");
  }

  await Veiculo.registrarEntrada({ placa: placa.toUpperCase(), modelo, cor });
  res.redirect('/dashboard');
};

const registrarSaidaVeiculo = async (req, res) => {
  const { placa } = req.params;
  await Veiculo.registrarSaida(placa);
  res.redirect('/dashboard');
};

const registrarRetornoVeiculo = async (req, res) => {
    const { placa } = req.params;
    const veiculo = await Veiculo.buscarPorPlaca(placa);
    if (veiculo) {
        await Veiculo.registrarEntrada({ placa: veiculo.placa, modelo: veiculo.modelo, cor: veiculo.cor });
    }
    res.redirect('/dashboard');
};

const alternarBloqueioVeiculo = async (req, res) => {
  const { placa } = req.params;
  await Veiculo.alternarBloqueio(placa);
  res.redirect('/dashboard');
};

module.exports = {
  exibirDashboard,
  registrarEntradaVeiculo,
  registrarSaidaVeiculo,
  registrarRetornoVeiculo,
  alternarBloqueioVeiculo
};