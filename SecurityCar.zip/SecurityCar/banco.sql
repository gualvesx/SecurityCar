-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           10.4.32-MariaDB - mariadb.org binary distribution
-- OS do Servidor:               Win64
-- HeidiSQL Versão:              12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Copiando estrutura do banco de dados para security_car_db
DROP DATABASE IF EXISTS `security_car_db`;
CREATE DATABASE IF NOT EXISTS `security_car_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `security_car_db`;

-- Copiando estrutura para tabela security_car_db.registros
DROP TABLE IF EXISTS `registros`;
CREATE TABLE IF NOT EXISTS `registros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `veiculo_placa` varchar(15) NOT NULL,
  `horario_entrada` datetime NOT NULL,
  `horario_saida` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `veiculo_placa` (`veiculo_placa`),
  CONSTRAINT `registros_ibfk_1` FOREIGN KEY (`veiculo_placa`) REFERENCES `veiculos` (`placa`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Copiando dados para a tabela security_car_db.registros: ~8 rows (aproximadamente)
INSERT INTO `registros` (`id`, `veiculo_placa`, `horario_entrada`, `horario_saida`) VALUES
	(1, 'RJZ1A23', '2025-09-17 13:19:16', NULL),
	(2, 'QWX4B56', '2025-09-17 10:19:16', NULL),
	(3, 'TGO-2025', '2025-09-17 15:19:16', '2025-09-17 15:51:57'),
	(4, 'FGH7C89', '2025-09-17 07:19:16', '2025-09-17 12:19:16'),
	(5, 'JKL0D12', '2025-09-16 09:19:16', '2025-09-16 17:19:16'),
	(6, 'GOL-2023', '2025-09-15 15:19:16', '2025-09-16 15:19:16'),
	(7, 'MNP3E45', '2025-09-15 15:19:16', '2025-09-16 15:19:16'),
	(8, 'MNP3E45', '2025-09-17 14:19:16', '2025-09-17 15:29:06'),
	(9, 'FGHU7G08', '2025-09-17 15:28:08', '2025-09-17 15:51:56'),
	(10, 'MNP3E45', '2025-09-17 15:29:09', '2025-09-17 15:29:15'),
	(11, 'MNP3E45', '2025-09-17 15:29:21', '2025-09-17 15:29:23'),
	(12, 'MNP3E45', '2025-09-17 15:47:30', '2025-09-17 15:47:40'),
	(13, 'MNP3E45', '2025-09-17 15:47:49', '2025-09-17 15:48:01'),
	(14, 'MNP3E45', '2025-09-17 15:48:03', '2025-09-17 15:51:55'),
	(15, 'MNP3E45', '2025-09-17 15:49:19', '2025-09-17 15:51:55'),
	(16, 'MNP3E45', '2025-09-17 15:49:21', '2025-09-17 15:51:55'),
	(17, 'MNP3E45', '2025-09-17 15:52:01', '2025-09-17 15:52:17'),
	(18, 'TGO-2025', '2025-09-17 15:52:02', NULL),
	(19, 'FGHU7G08', '2025-09-17 15:52:03', '2025-09-17 16:41:02'),
	(20, 'FGHU7G08', '2025-09-17 16:41:03', NULL);

-- Copiando estrutura para tabela security_car_db.usuarios
DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome_usuario` varchar(50) NOT NULL,
  `senha_hash` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nome_usuario` (`nome_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Copiando dados para a tabela security_car_db.usuarios: ~1 rows (aproximadamente)
INSERT INTO `usuarios` (`id`, `nome_usuario`, `senha_hash`) VALUES
	(1, 'seguranca', '$2b$10$D/1o3sR.Jv.wJ.d7E.QJ5uMjdX.G.yM9dJz.X/f9fS.ZzM9a8.z.e');

-- Copiando estrutura para tabela security_car_db.veiculos
DROP TABLE IF EXISTS `veiculos`;
CREATE TABLE IF NOT EXISTS `veiculos` (
  `placa` varchar(15) NOT NULL,
  `modelo` varchar(100) NOT NULL,
  `cor` varchar(50) NOT NULL,
  `bloqueado` tinyint(1) NOT NULL DEFAULT 0,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`placa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Copiando dados para a tabela security_car_db.veiculos: ~8 rows (aproximadamente)
INSERT INTO `veiculos` (`placa`, `modelo`, `cor`, `bloqueado`, `criado_em`) VALUES
	('FGH7C89', 'Jeep Compass', 'Preto', 0, '2025-09-17 18:19:16'),
	('FGHU7G08', 'Honda City Lx 2015', 'Prata', 0, '2025-09-17 18:28:08'),
	('GOL-2023', 'VW Gol', 'Cinza', 0, '2025-09-17 18:19:16'),
	('JKL0D12', 'Fiat Toro', 'Vermelho', 1, '2025-09-17 18:19:16'),
	('MBI-1000', 'Fiat Mobi', 'Branco', 0, '2025-09-17 18:19:16'),
	('MNP3E45', 'Renault Kwid', 'Branco', 1, '2025-09-17 18:19:16'),
	('QWX4B56', 'Hyundai HB20', 'Branco', 1, '2025-09-17 18:19:16'),
	('RJZ1A23', 'Chevrolet Onix', 'Prata', 0, '2025-09-17 18:19:16'),
	('TGO-2025', 'VW T-Cross', 'Azul', 1, '2025-09-17 18:19:16');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
